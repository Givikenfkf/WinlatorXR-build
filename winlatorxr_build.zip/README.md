# WinlatorXRBridge — Build bundle

This repository contains:
- `src/WinlatorXRBridge/WinlatorXRBridge.cs` — BepInEx plugin (C#).
- `src/openvr_shim/openvr_api_shim.cpp` — minimal OpenVR shim (C++).
- `src/winlator_c_wrapper/winlator_c_wrapper.cpp` — optional C wrapper for WinlatorXR.
- `.github/workflows/build-windows.yml` — GitHub Actions workflow to build Windows x64 DLLs.

How to use:
1. Create a GitHub repository and upload these files (or push the zip contents).
2. On GitHub, go to Actions → run the workflow (or push to `main`).
3. Download the build artifacts (openvr_api.dll and WinlatorXRBridge.dll) from the workflow run.
4. Place `WinlatorXRBridge.dll` into `BepInEx/plugins/WinlatorXRBridge/` in your Gorilla Tag install.
5. Place `openvr_api.dll` (and optionally `winlator_c_wrapper.dll`) beside `GorillaTag.exe`.

If you provide the actual exported function list of your WinlatorXR native DLL (e.g., `dumpbin /EXPORTS winlatorxr.dll` output), I will update the P/Invoke signatures and native wrapper to match exactly.

**Important:** Test in private lobbies to avoid bans. You must own the game to modify it.